public class Main {
    public static void main(String arsg[]){
        int num1 = 10;
        int num2 = 20;
        int result = num1 + num2;
        System.out.println(result);  
    }
}
