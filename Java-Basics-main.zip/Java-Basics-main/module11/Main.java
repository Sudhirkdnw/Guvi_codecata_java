public class Main {
        public static void main(String[] args){
              int[] A = new int[5];

              A[0] = 10;
              A[1] = 20;
              A[2] = 30;
              A[3] = 40;
              A[4] = 50;

              for(int i=0; i<A.length; i++) {
                System.out.println("Elements of array are: " + A[i]);
              }

        }
}