public class Main {
    public static void main(String args[])
    {
        int i = 0;
        while(i<=5){
            System.out.println("Hello javac!");
            i++;
        }

    
    }
    
}
