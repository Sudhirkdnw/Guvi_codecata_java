public class Main
{
    public static void main(String args[])
    {
        int x = 20;
        if (x > 10){
            System.out.println(true);
        }
        else {
            System.out.println(false);
        }
    }
}